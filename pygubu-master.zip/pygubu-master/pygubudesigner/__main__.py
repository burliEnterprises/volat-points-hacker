from pygubudesigner import main

if __name__ == '__main__':
    # first of all, show the versions
    main.start_pygubu()
